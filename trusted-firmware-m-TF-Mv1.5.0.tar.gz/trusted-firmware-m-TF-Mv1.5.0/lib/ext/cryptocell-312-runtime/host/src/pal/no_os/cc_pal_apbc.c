/*
 * Copyright (c) 2001-2019, Arm Limited and Contributors. All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "cc_pal_types.h"

void CC_PalApbcCntrInit(void)
{
    return;
}

void CC_PalApbcCntrValue(void)
{
    return;
}

CCError_t CC_PalApbcModeSelect(CCBool isApbcInc)
{
    CC_UNUSED_PARAM(isApbcInc);

    return 0;
}

