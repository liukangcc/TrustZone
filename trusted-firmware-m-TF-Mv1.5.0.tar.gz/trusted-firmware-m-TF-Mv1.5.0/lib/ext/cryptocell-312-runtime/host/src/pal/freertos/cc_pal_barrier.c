/*
 * Copyright (c) 2001-2019, Arm Limited and Contributors. All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */


void CC_PalWmb(void)
{
    return;
}

void CC_PalRmb(void)
{
    return;
}


