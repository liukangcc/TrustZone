# cryptocell-312-runtime

Refer to `cc312_cryptocell_runtime_software_developers_manual
<https://git.trustedfirmware.org/TF-M/trusted-firmware-m.git/plain/lib/ext/cryptocell-312-runtime/docs/cc312_cryptocell_runtime_software_developers_manual_101122_0103_01_en.pdf>`_
for APIs documentation.


Refer to `cc312_r1_oss_rt_sw-r1p3-00rel0_ReleaseNote
<https://git.trustedfirmware.org/TF-M/trusted-firmware-m.git/plain/lib/ext/cryptocell-312-runtime/docs/cc312_r1_oss_rt_sw-r1p3-00rel0_ReleaseNote.pdf>`_
for additional information ( contents, build commands and more ).

--------------

Copyright (c) 2001-2020, Arm Limited. All rights reserved.
