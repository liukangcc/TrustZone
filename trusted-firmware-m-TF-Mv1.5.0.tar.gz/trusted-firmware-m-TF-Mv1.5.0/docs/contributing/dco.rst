
###############################
Developer Certificate of Origin
###############################

.. include:: /dco.txt
   :literal:


-----------

*Copyright (c) 2019, Arm Limited. All rights reserved.*
